################################################################################################
# Date: 5/29/2024
# Author: Jee Hun Kim
#         Jonathan Rumley added new functions on 11/11/2024
# Description: Converts all cis-bp-format Position Weight Matrices (PWMs) in the input folder to
#               MEME format.
#               Enter the following command in the Terminal to run the program:
#               python3 execute_copy_terminal.py <input_folder> <output_folder>
################################################################################################

import os
import sys


def convert_pwm_to_meme(input_file, output_file):
    with open(input_file, 'r') as f:
        lines = f.readlines()

    header = lines[0].strip().split()
    if header != ["Pos", "A", "C", "G", "T"]:
        raise ValueError(f"Unexpected file format in {input_file}")

    pwm = []
    for line in lines[1:]:
        parts = line.strip().split()
        pwm.append([float(parts[1]), float(parts[2]), float(parts[3]), float(parts[4])])

    with open(output_file, 'w') as f:
        f.write("MEME version 4\n\n")
        f.write("ALPHABET= ACGT\n\n")
        f.write("strands: + -\n\n")
        f.write("Background letter frequencies:\n")
        f.write("A 0.25 C 0.25 G 0.25 T 0.25\n\n")

        f.write(f"MOTIF {os.path.basename(input_file).split('.')[0]}\n\n")
        f.write("letter-probability matrix: alength= 4 w= {} nsites= 20 E= 0\n".format(len(pwm)))
        for row in pwm:
            f.write(" ".join("{:.6f}".format(x) for x in row) + "\n")


def convert_all_pwms_in_folder(input_folder, output_folder):
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    for filename in os.listdir(input_folder):
        if filename.endswith(".txt"):
            input_file = os.path.join(input_folder, filename)
            output_file = os.path.join(output_folder, filename.replace(".txt", ".meme"))
            convert_pwm_to_meme(input_file, output_file)


if len(sys.argv) == 3:
    input_folder = sys.argv[1]
    output_folder = sys.argv[2]
elif len(sys.argv) < 3:
    print("\nYou must provide an input folder and an output folder. \n\nExiting.\n")
    sys.exit()
else:
    print("\nYou have provided too many arguments. \n\nExiting.\n")
    sys.exit()

convert_all_pwms_in_folder(input_folder, output_folder)
