import pandas as pd
import os

# paths
base_path = os.getcwd()
original_training_data_path = f'{base_path }/unc3_ASE_AIY_training_dataj_unc3_p0007478j_ASE_p000424403j_AIY_p000257719_8species.txt'

updated_coe_data_path = f'{base_path }/j2025118205510_all_info_normed.txt'
updated_ase_data_path = f'{base_path }/j2025118205637_all_info_normed.txt'
updated_aiy_data_path = f'{base_path }/j2025118205836_all_info_normed.txt'

output_path = f'{base_path}/training_data_9species.txt'

# functions
def filter_motif_df(motif_df_path, orig_df):
  motif_df = pd.read_csv(motif_df_path, sep='\t', header=0)
  return motif_df.merge(orig_df, on='ref_gene_name', how='right')

# main
def main():
  orig_df = pd.read_csv(original_training_data_path, sep='\t', header=0)
  orig_df = orig_df[['ref_gene_name','class_label']].drop_duplicates()

  motif_df1 = filter_motif_df(updated_coe_data_path, orig_df)
  motif_df2 = filter_motif_df(updated_ase_data_path, orig_df)
  motif_df3 = filter_motif_df(updated_aiy_data_path, orig_df)

  final_training_df = pd.concat([motif_df1, motif_df2, motif_df3])
  final_training_df_fill_na= final_training_df.fillna(0)
  #print(final_training_df_fill_na)
  #input()
  final_training_df_fill_na.to_csv(output_path, sep = '\t', index = False)
  #display(final_training_df.head())
  print('final shape of updated training data:', final_training_df.shape)

if __name__ == "__main__":
    main()