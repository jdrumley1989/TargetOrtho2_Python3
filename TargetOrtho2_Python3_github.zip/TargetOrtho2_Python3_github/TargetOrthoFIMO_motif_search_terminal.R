##### 
# Date: 5/23/2024
# Author: Jenny Tian
# Description: finds and separates out the motifs from fimo targetortho output, 
#              based on the chromosome (sequence name), and start and stop positions.
# Modified
# Date: 9/19/2024
# Modifier: Jonathan Rumley
# Modification: Enable functionality from Terminal
#
# Command must be as follows:
#   Rscript <file_path>/TargetOrthoFIMO_motif_search_terminal.R <input_file> <chromosome/contig/scaffold> <start_search_position> <stop_search_position>
#####


library(readr)
library(dplyr)
library(magrittr)

args <- commandArgs(trailingOnly=TRUE)

if (length(args) != 4){
  stop("4 arguments must be supplied. Argument 1 is the input file name. Argument 2 is the chromosome being filtered for. Argument 3 is the start position for filtering. Argument 4 is the stop position for filtering.")
}

#filepath  <- "/Applications/TargetOrtho2.0-master/TargetOrtho2.0/j2024522171014_TargetOrtho2.0_Results/fimo_out"

#df_celeg <- read_tsv(paste0(filepath, "/j2024522171014_c_eleg_fimo.txt"))

df_celeg <- read_tsv(args[1])

#summary(df_celeg)

#Filter
df_result <- df_celeg %>% 
  filter(sequence_name == args[2], start >= args[3], stop <= args[4])
  

#output_path <- "/Users/jonathanrumley/Documents/Hobert Lab Files/motif_data_analysis/Results"
#write_csv(df_result, paste0(output_path, "/c_eleg_coe_motif_unc-6_intron7_3prime_conserved_region.csv"))

#Write output file
out_file_name_header <- substr(args[1], 1, nchar(args[1])-4)

write_csv(df_result, paste0(out_file_name_header, "_filtered.csv"))