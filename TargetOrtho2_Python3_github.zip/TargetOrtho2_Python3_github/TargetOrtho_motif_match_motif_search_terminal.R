##### 
# Date: 5/23/2024
# Author: Jonathan Rumley mostly copied from TargetOrthoFIMO_motif_search.R by Jenny Tian
#         Jenny Tian updated with new functions on 6/4/2024. 
#         Jonathan Rumley updated with new functions on 9/21/2024
# Description: finds and separates out the motifs in particular genes from motif match targetortho output, 
#              based on the chromosome (sequence name), and start and stop positions. 
#
# Command must be as follows:
#   Rscript <file_path>/TargetOrtho_motif_match_motif_search_terminal.R <input_file> <reference_gene>
#####


library(readr)
library(dplyr)
library(magrittr)
library(janitor)

args <- commandArgs(trailingOnly=TRUE)

if (length(args) != 2){
  stop("2 arguments must be supplied. Argument 1 is the input file name. Argument 2 is the reference gene of interest.")
}

df_motif_match_spec <- read_csv(args[1])

#filepath  <- "/Applications/TargetOrtho2.0-master/TargetOrtho2.0/unc-42 sites/Nitta et al. Dmel unc-42/j2024913133841_TargetOrtho2.0_Results/motif_match_data_per_species"
#df_motif_match_spec <- read_csv(paste0(filepath, "/j2024913133841_c_eleg_genome_motif_match_results.csv"))

#print(df_motif_match_spec)

#str(df_motif_match_spec)

# change column names to replace space/special chars with underscores
df_motif_match_spec <- clean_names(df_motif_match_spec) 
#names(df_motif_match_spec)

#summary(df_motif_match_spec)
#print(df_motif_match_spec)

# filter dataframe to reference gene 
try(df_motif_match_result <- df_motif_match_spec %>% 
      filter(ref_gene_name == args[2]), silent = TRUE)
try(df_motif_match_result <- df_motif_match_spec %>%
      filter(reference_genome_ortholog == args[2]), silent = TRUE)

#summary(df_motif_match_result)
#print(df_motif_match_result)

# export file as csv: 
#output_path <- "/Users/jonathanrumley/Documents/Hobert Lab Files/motif_data_analysis/Results"

out_file_name_header <- substr(args[1], 1, nchar(args[1])-4)

write_csv(df_motif_match_result, paste0(out_file_name_header, "_filtered.csv"))
